<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\book;

class bookController extends Controller
{
    public function book(){
        $books = book::orderBy("bookid","asc")->paginate(10);

        return view("book", compact("books"));
    }
    // public function search(Request $request){
    //     $search=$request->get('search');
    //     $posts=DB::table
    // }
}