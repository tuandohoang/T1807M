<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(App\book::class, function (Faker $faker) {
    return [
        "title"=>$faker->name,
        "ISBN"=>$faker->randomFloat(0,100000,900000),
        "available"=>$faker->randomFloat(0,1,100),
    ];
});
